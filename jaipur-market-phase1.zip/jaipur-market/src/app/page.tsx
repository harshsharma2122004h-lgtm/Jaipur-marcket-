export default function HomePage() {
  return (
    <main style={{ fontFamily: "system-ui", padding: "2rem" }}>
      <h1>Jaipur Market</h1>
      <p>Phase 1 scaffold — storefront UI comes in a later phase.</p>
      <p>Working so far: database schema, and auth (register / login / logout / me).</p>
    </main>
  );
}
