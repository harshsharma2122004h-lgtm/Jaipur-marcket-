import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Jaipur Market",
  description: "Shop the best of Jaipur, online.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
